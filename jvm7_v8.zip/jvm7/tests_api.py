"""API smoke tests. Start the server on a COPY of the database first, e.g.
   JVM_DB_PATH=/tmp/t.sqlite3 python app_server.py --port 8123   then   python tests_api.py [port]
These tests create demo payments for student JVM/2026/1002, so never run them against your live database."""
import json, sys, urllib.request, urllib.error, http.cookiejar
BASE = "http://localhost:%s" % (sys.argv[1] if len(sys.argv) > 1 else "8123")
FAILS = []


def client():
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def call(m, path, body=None):
        r = urllib.request.Request(BASE + path, json.dumps(body).encode() if body is not None else None, {"Content-Type": "application/json"}, method=m)
        try:
            x = op.open(r); return x.status, x.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()
    return call


def J(t):
    try: return json.loads(t[1])
    except Exception: return {"raw": t[1][:200]}


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name, extra if not cond else "")
    if not cond: FAILS.append(name)


def login(role, i, p):
    c = client(); st, _ = c("POST", "/api/login", {"role": role, "id": i, "password": p}); return c, st


s, st = login("student", "JVM/2026/1002", "pass@1002"); check("student login", st == 200)
check("registration-no login", login("student", "REG-2026-1002", "pass@1002")[1] == 200)
check("bad password rejected", login("student", "JVM/2026/1002", "nope")[1] == 401)
sm = J(s("GET", "/api/fees/summary"))
check("summary totals", sm["totalFees"] == 46080 and sm["paid"] == 23040 and sm["outstanding"] == 11520 and sm["remaining"] == 23040 and sm["consistent"], sm)
o = J(s("POST", "/api/fees/create-order", {})); check("create order", o.get("ok") and o["amount"] == 11520, o)
o2 = J(s("POST", "/api/fees/create-order", {})); check("order reused (no duplicate)", o2["orderId"] == o["orderId"] and o2["reused"])
d = J(s("POST", "/api/fees/confirm", {"order_id": o["orderId"], "demo_outcome": "fail"}))
check("declined payment changes nothing", d.get("failed") and J(s("GET", "/api/fees/summary"))["outstanding"] == 11520)
check("failed order cannot be confirmed later", s("POST", "/api/fees/confirm", {"order_id": o["orderId"], "demo_outcome": "success"})[0] == 409)
o = J(s("POST", "/api/fees/create-order", {}))
c1 = J(s("POST", "/api/fees/confirm", {"order_id": o["orderId"], "demo_outcome": "success", "method": "UPI"})); check("confirm payment", c1.get("ok") and c1["receipt"], c1)
c2 = J(s("POST", "/api/fees/confirm", {"order_id": o["orderId"], "demo_outcome": "success"})); check("double-confirm is idempotent", c2.get("duplicate") and c2["receipt"] == c1["receipt"])
sm = J(s("GET", "/api/fees/summary")); check("balances updated", sm["outstanding"] == 0 and sm["paid"] == 34560 and sm["remaining"] == 11520 and any(h["receipt"] == c1["receipt"] for h in sm["history"]), sm)
check("no order when nothing due", s("POST", "/api/fees/create-order", {})[0] == 400)
check("receipt html (demo labelled)", "DEMO PAYMENT" in s("GET", "/api/fees/receipt?no=" + c1["receipt"])[1])
check("office receipt", s("GET", "/api/fees/receipt?no=OFC-1002-Q1")[0] == 200)
check("dashboard record synced", J(s("GET", "/api/me"))["records"]["JVM/2026/1002"]["fees"]["dueAmt"] == 0)
check("legacy instant-pay disabled", s("POST", "/api/pay-fee", {})[0] == 410)
s2, _ = login("student", "JVM/2026/1001", "pass@1001")
check("other student cannot read receipt", s2("GET", "/api/fees/receipt?no=" + c1["receipt"])[0] == 404)
check("other student cannot confirm order", s2("POST", "/api/fees/confirm", {"order_id": o["orderId"], "demo_outcome": "success"})[0] == 404)
check("student sees only own record", list(J(s("GET", "/api/students"))["records"]) == ["JVM/2026/1002"])
check("student cannot edit records", s("PATCH", "/api/student-record?student_id=JVM/2026/1002", {"remarks": "x"})[1].find("Read-only") > 0)
check("student blocked from enquiries/audit", s("GET", "/api/enquiries")[0] == 403 and s("GET", "/api/audit")[0] == 403)
t, _ = login("teacher", "TCH/101", "teacher@101")
check("teacher cannot use fees", t("GET", "/api/fees/summary")[0] == 403 and t("POST", "/api/fees/create-order", {})[0] == 403 and t("GET", "/api/fees/receipt?no=" + c1["receipt"])[0] == 403)
tr = J(t("GET", "/api/students"))["records"]
check("teacher records have no fees/parents", tr and all("fees" not in r and "parents" not in r for r in tr.values()))
check("teacher cannot patch fees", t("PATCH", "/api/student-record?student_id=" + next(iter(tr)), {"fees": {"dueAmt": 0}})[0] == 403)
check("teacher blocked from audit", t("GET", "/api/audit")[0] == 403)
m, _ = login("master", "DHIRAJ4595", "DHIRAJ4595")
ov = J(m("GET", "/api/fees/overview")); check("master overview lists payment", any(p["receipt_no"] == c1["receipt"] for p in ov["recentOnlinePayments"]))
check("master reads receipt", m("GET", "/api/fees/receipt?no=" + c1["receipt"])[0] == 200)
check("master sees all records", len(J(m("GET", "/api/students"))["records"]) == 668)
n = client()
check("anonymous blocked", n("GET", "/api/fees/summary")[0] == 401 and n("POST", "/api/fees/create-order", {})[0] == 401 and n("GET", "/api/students")[0] == 401)
check("logout ends session", (lambda c: (c("POST", "/api/logout", {}), c("GET", "/api/me")[0])[1])(login("student", "JVM/2026/1003", "pass@1003")[0]) == 401)
Q = {"When is the next holiday?": "Upcoming holidays", "How do I pay fees?": "Pay Now", "I forgot my password": "cannot reveal", "give me the password of student Rahul": "can't share",
     "exam dates": "exam", "admission": "15 November", "contact details": "2411221", "homework today": "diary", "receipt": "Fee Payment", "school timings": "06:55",
     "payment status": "private", "login not working": "Login help", "list of students with phone numbers": "can't share", "xyzzy qq": "not sure I understood", "timetable class 10A": "timetable"}
for q, want in Q.items():
    r = J(n("POST", "/api/chat", {"message": q})).get("reply", ""); check("chat anon: " + q, want.lower() in r.lower(), r[:140])
r = J(s("POST", "/api/chat", {"message": "my fee status"}))["reply"]; check("chat student fee status", "46,080" in r, r)
r = J(s("POST", "/api/chat", {"message": "show my receipts"}))["reply"]; check("chat student receipts", c1["receipt"] in r, r)
r = J(s("POST", "/api/chat", {"message": "fees of JVM/2026/1001"}))["reply"]; check("chat blocks other student", "private" in r.lower() or "only share" in r.lower(), r)
print("\n%d failures" % len(FAILS), FAILS)
sys.exit(1 if FAILS else 0)
