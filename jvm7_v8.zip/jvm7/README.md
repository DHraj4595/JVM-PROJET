# JVM Shyamali website — v7 upgrade

## Run
```
python app_server.py --port 8000      # Python 3.10+, no extra packages
```
Open http://127.0.0.1:8000 (do NOT use a static file server or file://). Existing accounts, teacher assignments and student records are unchanged (`private_data/`). The SQLite DB gets two new tables (`fee_orders`, `fee_payments`) automatically on first start — back up `private_data/school.sqlite3` before upgrading.

## Fee payments (Portal → Student/Parent login → "Fee Payment")
Shows total fees, paid, outstanding, remaining, instalment due dates, payment history and receipts. The server computes every amount; the browser can't set it.
Flow: `create-order` → gateway → `confirm`. Balance, history, receipt and dashboards (student, master) update only after the server records the payment, in one database transaction. Re-clicking/retrying returns the same receipt (no double charge); one open order per student; orders expire after 30 min; failed/declined payments change nothing. The old instant-pay endpoint is disabled.

Modes (`JVM_PAYMENT_MODE`):
- `demo` (default) — **no gateway, no real money.** Clearly labelled in the UI; receipts are watermarked DEMO.
- `razorpay` — set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`. Server creates the order and verifies the Razorpay HMAC signature before recording anything. **Not tested against live Razorpay** (no credentials/network here) — test with Razorpay test keys first. If keys are missing it falls back to demo.
- `disabled` — hides payment; office payment only.

Payments recorded before this upgrade are shown as "school office record" (derived from the existing fee fields, no invented transaction IDs).

## Chatbot
Knowledge base (server-side, `chat_kb`) covers admissions, fees, due dates, payment status/receipts (own account only after sign-in), calendar/holidays/exams/PTM (read live from the site's own calendar list), timetables, timings, teachers, achievements, events, contact, login and technical help, with a fallback. It refuses passwords, other students' data and staff personal contacts. Optional AI: `ANTHROPIC_API_KEY` or `JVM_OLLAMA_MODEL`.
Window: compact 340×460; − / % / + zoom (70–160%), % or ↺ resets zoom and position, drag by the header (double-click header re-docks), ⤢ maximise. Always clamped inside the viewport below the site header.

## Tests (run on a COPY of the DB — they create demo payments)
```
JVM_DB_PATH=/tmp/t.sqlite3 python app_server.py --port 8123
python tests_api.py 8123     # 50+ API/permission/payment/chatbot checks
python tests_ui.py 8123      # needs: pip install playwright && playwright install chromium
```
Both pass in the delivery environment. After editing `index.html` run `python build_pages.py`.

## Known limitations
- Razorpay live mode untested (see above); no webhook — if a customer pays but closes the browser before the confirm call, the office must reconcile manually.
- Receipts are HTML (print/save as PDF from the browser).
- Sessions are in server memory (restart = sign in again). Use HTTPS and change all demo passwords before going public (see README_DEPLOYMENT.txt).
- Homework/live attendance feeds don't exist in the data, so the chatbot points to the diary/portal instead of inventing answers.
- Tested in headless Chromium only (desktop, 390px phone, short-screen viewports); not on real iOS/Android devices.
